const app = new Vue({
    el: '#allWrapper',
    data: {
        stateMap: new Map([
            ['道北', '北海道'],
            ['道東', '北海道'],
            ['道南・道央', '北海道'],

            ['青森', '東北'],
            ['岩手', '東北'],
            ['宮城', '東北'],
            ['秋田', '東北'],
            ['山形', '東北'],
            ['福島', '東北'],

            ['茨城', '関東'],
            ['栃木', '関東'],
            ['群馬', '関東'],
            ['埼玉', '関東'],
            ['千葉', '関東'],
            ['東京', '関東'],
            ['神奈川', '関東'],

            ['新潟', '甲信越・北陸'],
            ['富山', '甲信越・北陸'],
            ['石川', '甲信越・北陸'],
            ['福井', '甲信越・北陸'],
            ['山梨', '甲信越・北陸'],
            ['長野', '甲信越・北陸'],

            ['岐阜', '東海'],
            ['静岡', '東海'],
            ['愛知', '東海'],
            ['三重', '東海'],

            ['滋賀', '近畿'],
            ['京都', '近畿'],
            ['大阪', '近畿'],
            ['兵庫', '近畿'],
            ['奈良', '近畿'],
            ['和歌山', '近畿'],

            ['鳥取', '中国'],
            ['島根', '中国'],
            ['岡山', '中国'],
            ['広島', '中国'],
            ['山口', '中国'],

            ['徳島', '四国'],
            ['香川', '四国'],
            ['愛媛', '四国'],
            ['高知', '四国'],

            ['福岡', '九州・沖縄'],
            ['佐賀', '九州・沖縄'],
            ['長崎', '九州・沖縄'],
            ['熊本', '九州・沖縄'],
            ['大分', '九州・沖縄'],
            ['宮崎', '九州・沖縄'],
            ['鹿児島', '九州・沖縄'],
            ['沖縄', '九州・沖縄'],
        ]),
        //所选都道府県
        duxian: "",
        //所选都道府県的href
        duxianHref: "",
        //所选音节Id
        yinjieId: "",
        //所选银行
        bankName: "",
        //所选银行的Id
        bankNameId: "",
    },
    mounted() {

        //pc
        const duxianDomPc = document.querySelectorAll('.txt.parentBtn')
        const bankNameDomPc = document.querySelectorAll('.txt.selectJaBtn')
        const backBtnDomPc=document.querySelector('#backBtn')

        duxianDomPc.forEach((item) => {
            item.addEventListener('click', (event) => {
                const clickDom = event.target
                this.duxian = clickDom.innerText
                this.duxianHref = clickDom.href
                this.bankNameId = this.getCaption(this.duxianHref, "#")
                document.querySelector(`#${this.bankNameId}`).style.display = 'block'
                document.querySelector('#backBtn').style.display='inline-block'
            })
        })
        
        backBtnDomPc.addEventListener('click',(event)=>{
            document.querySelector('#backBtn').style.display='none'
            document.querySelector(`#${this.bankNameId}`).style.display = 'none'
        })

        bankNameDomPc.forEach((item) => {
            item.addEventListener('click', (event) => {
                const clickDom = event.target
                this.bankName = clickDom.innerText

                $.ajax({
                    type: "post",
                    url: '/api/user/accountData/selectBank',
                    data: {
                        order_state:this.stateMap.get(this.duxian),
                        order_duxian:this.duxian,
                        order_bankName:this.bankName
                    },
                    dataType: "json",
                    cache: false,
                    async: true,
                    success: (data) => {
                        if (data.code == "200") {
                            window.location.assign(data.data.url)
                        } else {
                            window.alert("提出に失敗しました。やり直してください。")
                            location.reload()
                        }
                    },
                })
            })
        })

        //sp
        // const stateDomSp = document.querySelectorAll('#popup_jaModal .modalInner .list dt')
        // const duxianDomSp = document.querySelectorAll('.btnList .m_btn s_type01')
        // const yinjieDomSp=document.querySelectorAll('.modalInner .secModal dl')

        // stateDomSp.forEach((item) => {
        //     item.addEventListener('click', (event) => {
        //         const clickDom = event.target
        //         this.state = clickDom.innerText
        //         $(clickDom).next()[0].style.display=='block'?$(clickDom).next()[0].style.display=='none':$(clickDom).next()[0].style.display='block'
        //     })
        // })

        // duxianDomSp.forEach((item)=>{
        //     item.addEventListener('click',(event)=>{
        //         yinjieDomSp.forEach((item)=>{
        //             item.style.display="none"
        //         })
        //         const clickDom = event.target
        //         this.stateHref = clickDom.href
        //         this.yinjieId= this.getCaption(this.stateHref, "#")
        //         document.querySelector(`#${this.yinjieId}`).style.display = 'block'
        //     })
        // })

        // yinjieDomSp.forEach((item)=>{
        //     item.addEventListener('click',(event)=>{
        //         document.querySelector(`#popup_sel0101`).querySelectorAll('dl').forEach((item)=>{
        //             item.style.display="none"
        //         })
        //         const clickDom = event.target
        //          $(clickDom).next()[0].style.display=='block'?$(clickDom).next()[0].style.display=='none':$(clickDom).next()[0].style.display='block'
        //     })
        // })
    },
    methods: {
        getCaption(obj, str) {
            var index = obj.lastIndexOf(str);
            obj = obj.substring(index + 1, obj.length);
            return obj;
        },
        closeState() {
            this.state = ""
            document.querySelector(`#${this.bankNameId}`).style.display = 'none'
        }
    },
    watch: {
    }
})